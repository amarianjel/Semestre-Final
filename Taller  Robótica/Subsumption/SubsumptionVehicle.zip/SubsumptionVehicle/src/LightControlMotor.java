import lejos.nxt.*;
import lejos.nxt.addon.RCXLightSensor;



public class LightControlMotor
{

  // Commands for the motors
  private final static int forward  = 1,
                           backward = 2,
                           stop     = 3;
 
  //private LightSensor light; // NXT light sensor
  private MotorPort motor;
  private RCXLightSensor light;
  
  public LightControlMotor(SensorPort p, MotorPort m) {
	  
	  //light = new LightSensor(p); // NXT light sensor
	  //light.setFloodlight(true);

	  light = new RCXLightSensor(p); 
	  light.setFloodlight(true);
	  motor = m;
  }
  
public int getValue(){
	  return light.readValue();
  }
  
void reactOnLight() {
	int read = light.readValue(); // Values in between 28 - 51 (light)
	motor.controlMotor(read + 30, forward); // Add offset
}

}
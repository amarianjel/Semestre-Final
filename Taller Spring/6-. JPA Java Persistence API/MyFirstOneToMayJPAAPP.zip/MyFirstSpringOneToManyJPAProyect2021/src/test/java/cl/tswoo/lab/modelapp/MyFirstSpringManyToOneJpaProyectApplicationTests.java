package cl.tswoo.lab.modelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstSpringManyToOneJpaProyectApplicationTests {

	@Test
	void contextLoads() {
	}

}

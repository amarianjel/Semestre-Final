package com.example;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.domain.Product;
import com.example.repository.ProductRepository;

@SpringBootApplication
public class SpringBootJPAExampleApplication implements CommandLineRunner{
	
	@Autowired
	private ProductRepository productRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJPAExampleApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		
		Product p = new Product("Chuica","chuica.jpg",new BigInteger("5000"),"ak1433",2);
		productRepository.save(p);
		
	}
}

package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

@SpringBootApplication
public class SpringBootMVCOneToManyJPAMessagesExampleApplication implements CommandLineRunner{
	
	@Autowired
	//private ProductRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootMVCOneToManyJPAMessagesExampleApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		//Product p = new Product("Sopaipleto","sopaipleto.jsp",new BigInteger("350"),"sopaipletox",1);
		//repository.save(p);
	}
	
	@Bean(name = "messageSource")
	public ReloadableResourceBundleMessageSource messageSource() {
	  ReloadableResourceBundleMessageSource messageBundle = new ReloadableResourceBundleMessageSource();
	  messageBundle.setBasename("classpath:messages/messages");
	  messageBundle.setDefaultEncoding("UTF-8");
	  return messageBundle;
	}
		
}

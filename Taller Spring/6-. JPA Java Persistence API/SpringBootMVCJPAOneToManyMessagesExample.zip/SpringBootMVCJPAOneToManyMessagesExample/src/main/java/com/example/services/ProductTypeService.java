package com.example.services;

import com.example.domain.ProductType;

public interface ProductTypeService {
	
	Iterable<ProductType> listAllProductTypes();

    ProductType getProducTypetById(Integer id);

    ProductType saveProductType(ProductType productType);

    void deleteProductType(Integer id);

}

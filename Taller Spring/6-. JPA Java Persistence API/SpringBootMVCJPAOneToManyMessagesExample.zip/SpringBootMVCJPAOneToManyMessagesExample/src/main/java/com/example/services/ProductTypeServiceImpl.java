package com.example.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.ProductType;
import com.example.repositories.ProductTypeRepositories;

@Service
public class ProductTypeServiceImpl implements ProductTypeService{
	private ProductTypeRepositories productTypeRepositories;
	
	@Autowired
	public void setProductTypeRepositories(ProductTypeRepositories productTypeRepositories){
		this.productTypeRepositories = productTypeRepositories;
	}

	@Override
	public Iterable<ProductType> listAllProductTypes() {
		return productTypeRepositories.findAll();
	}

	@Override
	public ProductType getProducTypetById(Integer id) {
		return productTypeRepositories.findOne(id);
	}

	@Override
	public ProductType saveProductType(ProductType productType) {
		return productTypeRepositories.save(productType);
	}

	@Override
	public void deleteProductType(Integer id) {
		productTypeRepositories.delete(id);
		
	}

}

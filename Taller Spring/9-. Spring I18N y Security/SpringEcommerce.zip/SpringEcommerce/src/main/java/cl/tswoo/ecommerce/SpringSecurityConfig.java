package cl.tswoo.ecommerce;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//import cl.tswoo.ecommerce.auth.handler.LoginSuccessHandler;
import cl.tswoo.ecommerce.services.UserDetailsServiceImplementation;

@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true)
@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {
	
	//@Autowired
	//private LoginSuccessHandler loginSuccessHandler;
	
	@Autowired
	private UserDetailsServiceImplementation userDetailsService;
	
	@Bean	
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests()
			.antMatchers("/", "/css/**", "/js/**", "/images/**","/webjars/**","/locale")
			.permitAll()
			//.antMatchers("/customer/").hasAnyRole("USER")
			//.antMatchers("/customer/list").hasAnyRole("USER")
			//.antMatchers("/sale/list").hasAnyRole("USER")
			//.antMatchers("/customer/**").hasAnyRole("ADMIN")
			//.antMatchers("/sale/**").hasAnyRole("ADMIN")
			//.anyRequest().authenticated()
			.and()
		.formLogin()
			//.successHandler(loginSuccessHandler)
			//.loginPage("/login")
			.permitAll()
			.and()
		.logout()
			.permitAll()
			.and()
		.exceptionHandling()
			.accessDeniedPage("/access-denied");

	}

	@Autowired
	public void configurerGlobal(AuthenticationManagerBuilder build) throws Exception
	{
		build.userDetailsService(userDetailsService)
		.passwordEncoder(this.passwordEncoder());

	}
}

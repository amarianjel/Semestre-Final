package cl.tswoo.ecommerce.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cl.tswoo.ecommerce.models.Sale;
import cl.tswoo.ecommerce.services.SaleServiceImplmentation;

@RequestMapping("/sale")
@Controller
public class SaleController {
	
	@Autowired
	SaleServiceImplmentation service;
	
	@GetMapping({"/","/list"})
	public String list(Model model) {
		List<Sale> list = service.listAll();
		model.addAttribute("sales", list);
		return "sale/list";
	}
	
	@GetMapping("/delete")
	public String delete(@RequestParam Integer id) {
		service.delete(id);
		return "redirect:sale/list";
	}
	
	@GetMapping("/update")
	public String update(@RequestParam Integer id, Model model) {
		Sale sale = service.getById(id);
		model.addAttribute("sale", sale);
		return "sale/form";
	}
	
	@PostMapping("/update")
	public String update(Sale sale, Model model) {
		
		service.save(sale);
		
		return "redirect:sale/list";
	}
	
	@GetMapping("/create")
	public String create(Model model) {
		Sale sale = new Sale();
		model.addAttribute("sale", sale);
		return "sale/form";
	}
	
	@GetMapping("/detail")
	public String detail(@RequestParam Integer id, Model model) {
		Sale sale = service.getById(id);
		model.addAttribute("sale", sale);
		return "sale/detail";
	}

}

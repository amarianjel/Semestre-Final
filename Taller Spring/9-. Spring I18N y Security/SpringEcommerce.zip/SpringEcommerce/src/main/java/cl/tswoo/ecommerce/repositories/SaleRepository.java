package cl.tswoo.ecommerce.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.tswoo.ecommerce.models.Sale;

@Repository
public interface SaleRepository extends JpaRepository<Sale, Integer> {

}

package cl.tswoo.ecommerce.services;

import java.util.List;

import cl.tswoo.ecommerce.models.Customer;


public interface CustomerService {
	
	List<Customer> listAll();
	void save(Customer customer);
	void delete(int id);
	Customer getById(int id); 
}

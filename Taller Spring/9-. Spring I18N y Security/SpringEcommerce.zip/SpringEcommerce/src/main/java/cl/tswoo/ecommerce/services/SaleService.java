package cl.tswoo.ecommerce.services;

import java.util.List;

import cl.tswoo.ecommerce.models.Sale;


public interface SaleService {
	
	List<Sale> listAll();
	void save(Sale sale);
	void delete(int id);
	Sale getById(int id); 
}

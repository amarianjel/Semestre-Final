package cl.tswoo.ecommerce.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.tswoo.ecommerce.models.Sale;
import cl.tswoo.ecommerce.repositories.SaleRepository;

@Service
public class SaleServiceImplmentation implements SaleService {
	
	@Autowired
	private SaleRepository repository;

	@Override
	public List<Sale> listAll() {
		return repository.findAll();
	}

	@Override
	public void save(Sale sale) {
		repository.save(sale);

	}

	@Override
	public void delete(int id) {
		repository.deleteById(id);

	}

	@Override
	public Sale getById(int id) {
		return repository.getOne(id);
	}

}

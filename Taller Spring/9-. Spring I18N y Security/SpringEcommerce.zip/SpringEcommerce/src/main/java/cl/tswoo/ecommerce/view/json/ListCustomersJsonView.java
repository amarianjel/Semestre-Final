package cl.tswoo.ecommerce.view.json;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import cl.tswoo.ecommerce.models.Customer;

@Component("customer/list.json")
public class ListCustomersJsonView extends MappingJackson2JsonView {
	@Override
	protected Object filterModel(Map<String, Object> model) {
		List<Customer> customers = (List<Customer>) model.get("customers");
		
		return super.filterModel(model);
	}

}

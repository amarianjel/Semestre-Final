package cl.tswoo.ecommerce.view.pdf;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfTable;
import com.lowagie.text.pdf.PdfWriter;

import cl.tswoo.ecommerce.models.Customer;

@Component("customer/list.pdf")
public class ListCustomersPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Customer> customers = (List<Customer>) model.get("customers");
		
		PdfPTable tabla = new PdfPTable(4);
		tabla.addCell("Name");
		tabla.addCell("Lastname");
		tabla.addCell("Email");
		tabla.addCell("Created At");
		for (Customer customer : customers) {
			tabla.addCell(customer.getName());
			tabla.addCell(customer.getLastName());
			tabla.addCell(customer.getEmail());
			tabla.addCell(customer.getCreatedAt().toString());
		}
		document.add(tabla);
	}

}

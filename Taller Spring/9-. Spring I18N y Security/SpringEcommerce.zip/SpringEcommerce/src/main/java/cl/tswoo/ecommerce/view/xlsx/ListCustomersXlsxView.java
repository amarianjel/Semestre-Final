package cl.tswoo.ecommerce.view.xlsx;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import cl.tswoo.ecommerce.models.Customer;

@Component("customer/list.xlsx")
public class ListCustomersXlsxView extends AbstractXlsView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposition", "attachment; filename=\"customers_view.xlsx\"");
		List<Customer> listCustomers = (List<Customer>) model.get("customers");
		
		Sheet sheet = workbook.createSheet("Lista clientes");
		
		sheet.createRow(0).createCell(0).setCellValue("Lista de Clientes");
		Row header = sheet.createRow(2);
		header.createCell(0).setCellValue("id");
		header.createCell(1).setCellValue("name");
		header.createCell(2).setCellValue("lastName");
		header.createCell(3).setCellValue("created at");
		
		CellStyle cellStyle = workbook.createCellStyle();
		CreationHelper createHelper = workbook.getCreationHelper();
		cellStyle.setDataFormat(
		    createHelper.createDataFormat().getFormat("d/m/yyyy"));
		
		for (int i = 0; i < listCustomers.size(); i++) {
			Row row = sheet.createRow(i+3);
			row.createCell(0).setCellValue(listCustomers.get(i).getId());
			row.createCell(1).setCellValue(listCustomers.get(i).getName());
			row.createCell(2).setCellValue(listCustomers.get(i).getLastName());
			Cell cellDate = row.createCell(3);
			cellDate.setCellValue(listCustomers.get(i).getCreatedAt());
			cellDate.setCellStyle(cellStyle);
		}
		
	}

	
}
